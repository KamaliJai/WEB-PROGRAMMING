# PulseMeet v3 - Interactive Live Polling & Quiz Platform

A professional React + Vite web programming project inspired by modern live quiz/polling platforms.

## Features
- Professional gradient login/onboarding
- Dashboard with statistics and recommendations
- Search, topic and difficulty filters
- Favorites
- Timed quiz player
- Room-code demo mode
- Simulated participant count
- Automatic scoring and result visualization
- Leaderboard-style live session experience
- Attempt history
- Performance analytics and achievement badges
- Dark/light mode
- Quiz builder with custom questions
- LocalStorage persistence
- Responsive desktop/tablet/mobile UI

## Tech Stack
- HTML5
- CSS3
- JavaScript ES6+
- React 18
- Vite
- Lucide React
- Browser localStorage

## Run in VS Code
```bash
npm install
npm run dev
```
Open the local URL shown by Vite, normally `http://localhost:5173/`.

## Build
```bash
npm run build
```

## Notes
This is a frontend demonstration project. The room code and participant count are simulated locally; a real multi-user room can later be implemented using Firebase, Supabase, WebSockets or Node.js.
